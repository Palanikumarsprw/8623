# Google APIs for Mobile: Quickstarts 

A collection of quickstart samples demonstrating the Google APIs for 
[Android](https://developers.google.com/android) and [iOS](https://developers.google.com/ios).

## How to make contributions?
Please read and follow the steps in the [CONTRIBUTING.md](CONTRIBUTING.md)

## License
See [LICENSE](LICENSE)
