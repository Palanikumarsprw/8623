<?php

return array(

	'save'   => 'Save',
	'update'   => 'Update',
	'cancel'   => 'Cancel',
	'reset'   => 'Reset',
	'edit'   => 'Edit',
	'delete' => 'Delete',
	'back' => 'Back',
);
