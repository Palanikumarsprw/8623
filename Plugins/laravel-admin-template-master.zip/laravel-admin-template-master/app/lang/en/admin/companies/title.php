<?php

return array(

	'management'    => 'Company Management',
	'update'        => 'Update a Company',
	'delete'        => 'Delete a Company',
	'create'  		=> 'Create a New Company',

);
