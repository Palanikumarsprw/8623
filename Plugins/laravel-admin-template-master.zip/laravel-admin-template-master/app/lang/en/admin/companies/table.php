<?php

return array(

	'name' => 'Name',
	'database'  => 'Database',
	'created_at' => 'Created at',

);
