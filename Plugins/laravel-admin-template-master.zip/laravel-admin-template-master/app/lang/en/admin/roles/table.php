<?php

return array(

	'name'       => 'Name',
	'users'      => '# of Users',
	'created_at' => 'Created at',
	'updated_at' => 'Updated at',

);
