<?php

return array(

	'user_management'    => 'User Management',
	'user_update'        => 'Update a User',
	'user_delete'        => 'Delete a User',
	'create_a_new_user'  => 'Create a New User',

);
