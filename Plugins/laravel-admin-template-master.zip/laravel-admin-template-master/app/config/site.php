<?php

return array(

	/**
	 * CMS Site Configuration
	 */

	// Site Name
	'name' => 'Laravel Admin Template',

	);
