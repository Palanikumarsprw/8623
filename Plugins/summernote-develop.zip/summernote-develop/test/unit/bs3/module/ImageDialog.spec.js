/**
 * ImageDialog.spec.js
 * (c) 2015~ Summernote Team
 * summernote may be freely distributed under the MIT license./
 */
/* jshint unused: false */
define([
  'chai',
  'summernote/bs3/module/ImageDialog'
], function (chai, ImageDialog) {
  'use strict';

  var expect = chai.expect;

  describe('bs3:module.ImageDialog', function () {
  });
});
