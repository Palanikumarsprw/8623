package com.javapapers.android.gcm.chat;

/**
 * Created by Joe on 5/28/2014.
 */
public class Config {
    // Google Project Number
    static final String GOOGLE_PROJECT_ID = "519264447280";
}
